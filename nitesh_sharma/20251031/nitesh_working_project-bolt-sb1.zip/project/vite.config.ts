import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
  server: {
    proxy: {
      '/api/generate': {
        target: 'https://bharat42010.app.n8n.cloud',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/generate/, '/webhook-test/ee3e9945-97dc-470e-9ee5-053d528e15eb'),
      },
      '/api/publish': {
        target: 'https://bharat42010.app.n8n.cloud',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/publish/, '/webhook-test/20c84917-2446-49f4-9270-28efb9d31ed5'),
      },
    },
  },
});
