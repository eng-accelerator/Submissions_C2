import { useState } from 'react';
import { Sparkles, Send, Linkedin } from 'lucide-react';

type FormData = {
  theme: string;
  post_type: string;
  length: string;
  tone: string;
};

function App() {
  const [formData, setFormData] = useState<FormData>({
    theme: '',
    post_type: 'Thought Leadership',
    length: 'Medium (3-8 lines)',
    tone: 'Professional / Formal',
  });
  const [generatedPost, setGeneratedPost] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [error, setError] = useState('');
  const [publishResponse, setPublishResponse] = useState<string>('');

  const handleGenerate = async () => {
    if (!formData.theme.trim()) {
      setError('Please enter a theme or idea for your post');
      return;
    }

    setError('');
    setIsGenerating(true);
    setPublishResponse('');

    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to generate post');
      }

      const text = await response.text();
      setGeneratedPost(text);
    } catch (err) {
      setError('Unable to generate post. Please check your webhook configuration.');
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePublish = async () => {
    if (!generatedPost.trim()) {
      setError('No post to publish');
      return;
    }

    setError('');
    setIsPublishing(true);
    setPublishResponse('');

    try {
      const response = await fetch('/api/publish', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          post_text: generatedPost,
          metadata: formData,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to publish post');
      }

      const data = await response.json();
      setPublishResponse('Post published successfully!');
      console.log('Publish response:', data);
    } catch (err) {
      setError('Unable to publish post. Please check your webhook configuration.');
      console.error(err);
    } finally {
      setIsPublishing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      <div className="max-w-5xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Linkedin className="w-10 h-10 text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-900">Viral LinkedIn Post Generator</h1>
          </div>
          <p className="text-lg text-gray-600">Create engaging LinkedIn content in seconds</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">Post Configuration</h2>

            <div className="space-y-6">
              <div>
                <label htmlFor="theme" className="block text-sm font-medium text-gray-700 mb-2">
                  Theme / Idea *
                </label>
                <input
                  id="theme"
                  type="text"
                  value={formData.theme}
                  onChange={(e) => setFormData({ ...formData, theme: e.target.value })}
                  placeholder="e.g., AI in healthcare"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                />
              </div>

              <div>
                <label htmlFor="post_type" className="block text-sm font-medium text-gray-700 mb-2">
                  Post Type / Category
                </label>
                <select
                  id="post_type"
                  value={formData.post_type}
                  onChange={(e) => setFormData({ ...formData, post_type: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                >
                  <option>Thought Leadership</option>
                  <option>Industry Insights</option>
                  <option>How-to / Educational</option>
                  <option>Personal Story</option>
                  <option>Opinion</option>
                  <option>Announcement</option>
                  <option>Case Study</option>
                </select>
              </div>

              <div>
                <label htmlFor="length" className="block text-sm font-medium text-gray-700 mb-2">
                  Length
                </label>
                <select
                  id="length"
                  value={formData.length}
                  onChange={(e) => setFormData({ ...formData, length: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                >
                  <option>Short (1-3 lines)</option>
                  <option>Medium (3-8 lines)</option>
                  <option>Long (8+ lines)</option>
                </select>
              </div>

              <div>
                <label htmlFor="tone" className="block text-sm font-medium text-gray-700 mb-2">
                  Tone
                </label>
                <select
                  id="tone"
                  value={formData.tone}
                  onChange={(e) => setFormData({ ...formData, tone: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                >
                  <option>Inspirational</option>
                  <option>Personal Story</option>
                  <option>Professional / Formal</option>
                  <option>GenZ / Casual</option>
                  <option>Humorous</option>
                  <option>Motivational</option>
                </select>
              </div>

              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 px-6 rounded-lg transition flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-md hover:shadow-lg"
              >
                <Sparkles className="w-5 h-5" />
                {isGenerating ? 'Generating...' : 'Generate Post'}
              </button>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">Generated Post</h2>

            <textarea
              value={generatedPost}
              onChange={(e) => setGeneratedPost(e.target.value)}
              placeholder="Your generated LinkedIn post will appear here. You can edit it before publishing."
              className="w-full h-64 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition resize-none mb-6"
            />

            <button
              onClick={handlePublish}
              disabled={isPublishing || !generatedPost}
              className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-4 px-6 rounded-lg transition flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-md hover:shadow-lg"
            >
              <Send className="w-5 h-5" />
              {isPublishing ? 'Publishing...' : 'Publish to LinkedIn'}
            </button>

            {error && (
              <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            )}

            {publishResponse && (
              <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-700">{publishResponse}</p>
              </div>
            )}

            <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-xs text-blue-700 font-medium mb-2">Configuration Required:</p>
              <p className="text-xs text-blue-600">
                Update vite.config.ts with your n8n webhook URLs to enable generate and publish functionality.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
